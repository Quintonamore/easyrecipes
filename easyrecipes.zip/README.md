# Recipes

Recipes is an Android application that allows users to easily save recipes to their phone. 

Current Features:

Web browser to browse through recipes, and then parse the recipe data and view it.

Planned Features:

Implement SQLite Database to store the recipes.
Add functionality to allow users to add their own custom recipes.
Add more sites to be able to save recipes from.


# Acknowledgments

* [JSoup](http://jsoup.org) - for parsing HTML files

# Alpha Testing

If you'd like to test the alpha, please let me know. 
