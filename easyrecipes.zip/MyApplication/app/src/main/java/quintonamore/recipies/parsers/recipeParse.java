package quintonamore.recipies.parsers;

import java.io.Serializable;

import quintonamore.recipies.models.recipe;

/**
 * Created by teas9 on 3/11/2017.
 *
 * Polymorphism at its finest. Should expand on this.
 */

public class recipeParse implements Serializable {


    public recipe getRecipe(){
        return null;
    }

}
